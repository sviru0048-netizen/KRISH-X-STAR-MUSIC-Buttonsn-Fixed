import config
from VISHALMUSIC import app
from VISHALMUSIC.utils.colored_buttons import styled_button


def start_panel(_):
    # Add me = success (green, positive CTA), Channel = primary (blue, info)
    buttons = [
        [
            styled_button(text=_["S_B_1"], url=f"https://t.me/{app.username}?startgroup=true", style="success"),
            styled_button(text=_["S_B_2"], url=config.SUPPORT_CHANNEL, style="primary"),
        ],
    ]
    return buttons


async def private_panel(_):
    # Screenshot-style working menu: Add, Help, Support and Channel.
    buttons = [
        [
            styled_button(
                text=_["S_B_1"],
                url=f"https://t.me/{app.username}?startgroup=true",
                style="success",
            ),
        ],
        [
            styled_button(
                text=_["S_B_3"],
                callback_data="open_help",
                style="success",
            ),
        ],
        [
            styled_button(
                text=_["S_B_4"],
                url=config.SUPPORT_CHAT,
                style="primary",
            ),
            styled_button(
                text=_["S_B_2"],
                url=config.SUPPORT_CHANNEL,
                style="primary",
            ),
        ],
    ]
    return buttons
