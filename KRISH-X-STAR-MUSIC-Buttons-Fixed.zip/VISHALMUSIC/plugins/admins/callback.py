# ═══════════════════════════════════════════════════════════
#        😎  KRISH X STAR MUSIC BOT  😎
#   GitHub : t.me/iwanthotpinkpussy
#   Developer : @iwanthotpinkpussy | Telegram
#   Module : Admin Callback Query Handler
# ═══════════════════════════════════════════════════════════

import asyncio
import random

from pyrogram import filters
from pyrogram.types import CallbackQuery

from config import (
    BANNED_USERS,
    lyrical,
    SOUNCLOUD_IMG_URL,
    STREAM_IMG_URL,
    SUPPORT_CHAT,
    TELEGRAM_AUDIO_URL,
    TELEGRAM_VIDEO_URL,
    adminlist,
    confirmer,
    votemode,
)
from strings import get_string
from VISHALMUSIC import YouTube, app
from VISHALMUSIC.core.call import VISHAL
from VISHALMUSIC.misc import SUDOERS, db
from VISHALMUSIC.utils.stream.autoplay import is_autoplay_on
from VISHALMUSIC.utils.database import (
    get_active_chats,
    get_assistant,
    get_lang,
    get_upvote_count,
    is_active_chat,
    is_music_playing,
    is_muted,
    is_nonadmin_chat,
    music_off,
    music_on,
    mute_off,
    mute_on,
    set_loop,
)
from VISHALMUSIC.utils.decorators import ActualAdminCB, languageCB
from VISHALMUSIC.utils.formatters import seconds_to_min, time_to_seconds
from VISHALMUSIC.utils.inline import close_markup
from VISHALMUSIC.utils.inline.play import colored_stream_markup, colored_stream_markup_timer, generate_progress_bar
from VISHALMUSIC.utils.colored_buttons import (
    styled_button,
    buttons_to_inline_markup,
    edit_reply_markup_colored,
    smart_send_message as send_message_colored,
    smart_send_photo as send_photo_colored,
    smart_edit_message_text as edit_message_text_colored,
    smart_edit_message_caption as edit_message_caption_colored,
)
from VISHALMUSIC.utils.stream.autoclear import auto_clean
from VISHALMUSIC.utils.thumbnails import get_thumb


upvoters = {}


def parse_chat_info(chat_info: str):
    if "_" in chat_info:
        parts = chat_info.split("_")
        return int(parts[0]), parts[1]
    return int(chat_info), None


async def handle_upvote(callback: CallbackQuery, chat_id: int, counter, _):
    message_id = callback.message.id

    votemode.setdefault(chat_id, {}).setdefault(message_id, 0)
    upvoters.setdefault(chat_id, {}).setdefault(message_id, [])

    user_id = callback.from_user.id
    if user_id in upvoters[chat_id][message_id]:
        upvoters[chat_id][message_id].remove(user_id)
        votemode[chat_id][message_id] -= 1
    else:
        upvoters[chat_id][message_id].append(user_id)
        votemode[chat_id][message_id] += 1

    required_upvotes = await get_upvote_count(chat_id)
    current_upvotes = int(votemode[chat_id][message_id])
    if current_upvotes >= required_upvotes:
        votemode[chat_id][message_id] = required_upvotes
        try:
            stored = confirmer[chat_id][message_id]
            current = db.get(chat_id, [])
            if not current or not isinstance(current, list) or len(current) == 0:
                return await callback.edit_message_text("ғᴀɪʟᴇᴅ.")
            current = current[0]
        except Exception:
            return await callback.edit_message_text("ғᴀɪʟᴇᴅ.")
        try:
            if current.get("vidid") != stored.get("vidid") or current.get("file") != stored.get("file"):
                return await callback.edit_message_text(_["admin_35"])
        except Exception:
            return await callback.edit_message_text(_["admin_36"])
        try:
            await callback.edit_message_text(_["admin_37"].format(required_upvotes))
        except Exception:
            pass
        return counter if counter is not None else "UpVote", "ᴜᴘᴠᴏᴛᴇs"
    else:
        if user_id in upvoters[chat_id][message_id]:
            await callback.answer(_["admin_38"], show_alert=True)
        else:
            await callback.answer(_["admin_39"], show_alert=True)
        markup = [[styled_button(
            text=f"👍 {current_upvotes}",
            callback_data=f"ADMIN  UpVote|{chat_id}_{counter if counter is not None else chat_id}",
            style="primary",
        )]]
        await callback.answer(_["admin_40"], show_alert=True)
        await edit_reply_markup_colored(
            chat_id=callback.message.chat.id,
            message_id=callback.message.id,
            reply_markup=markup,
        )
        return None, None


@app.on_callback_query(filters.regex("unban_assistant"))
async def unban_assistant(_, callback: CallbackQuery):
    chat_id = callback.message.chat.id
    userbot = await get_assistant(chat_id)
    try:
        await app.unban_chat_member(chat_id, userbot.id)
        await callback.answer(
            "ᴍʏ ᴀssɪsᴛᴀɴᴛ ɪᴅ ᴜɴʙᴀɴɴᴇᴅ sᴜᴄᴄᴇssғᴜʟʟʏ🥰🥳\n\n➻ ɴᴏᴡ ʏᴏᴜ ᴄᴀɴ ᴘʟᴀʏ sᴏɴɢs🫠🔉\n\nTʜᴀɴᴋ ʏᴏᴜ💗",
            show_alert=True,
        )
    except Exception:
        await callback.answer(
            "Fᴀɪʟᴇᴅ ᴛᴏ ᴜɴʙᴀɴ ᴍʏ ᴀssɪsᴛᴀɴᴛ ʙᴇᴄᴀᴜsᴇ ɪ ᴅᴏɴ'ᴛ ʜᴀᴠᴇ ʙᴀɴ ᴘᴏᴡᴇʀ\n\n➻ Pʟᴇᴀsᴇ ᴘʀᴏᴠɪᴅᴇ ᴍᴇ ʙᴀɴ ᴘᴏᴡᴇʀ sᴏ ᴛʜᴀᴛ ɪ ᴄᴀɴ ᴜɴʙᴀɴ ᴍʏ ᴀssɪsᴛᴀɴᴛ ɪᴅ",
            show_alert=True,
        )



@app.on_callback_query(filters.regex("ADMIN") & ~BANNED_USERS)
@languageCB
async def manage_callback(client, callback: CallbackQuery, _):
    data = callback.data.strip().split(None, 1)[1]
    command, chat_info = data.split("|", 1)
    chat_id, counter = parse_chat_info(chat_info)

    if not await is_active_chat(chat_id):
        return await callback.answer(_["general_5"], show_alert=True)

    user_mention = callback.from_user.mention

    if command == "UpVote":
        new_command, new_mention = await handle_upvote(callback, chat_id, counter, _)
        if new_command is None:
            return
        command = new_command
        user_mention = new_mention
    else:
        if not await is_nonadmin_chat(callback.message.chat.id) and callback.from_user.id not in SUDOERS:
            admins = adminlist.get(callback.message.chat.id)
            if not admins:
                return await callback.answer(_["admin_13"], show_alert=True)
            if callback.from_user.id not in admins:
                return await callback.answer(_["admin_14"], show_alert=True)

    if command == "Pause":
        if not await is_music_playing(chat_id):
            return await callback.answer(_["admin_1"], show_alert=True)
        await callback.answer()
        await music_off(chat_id)
        await VISHAL.pause_stream(chat_id)
        await callback.message.reply_text(
            text=_["admin_2"].format(user_mention),
            reply_markup=buttons_to_inline_markup(close_markup(_)),
        )

    elif command == "Resume":
        if await is_music_playing(chat_id):
            return await callback.answer(_["admin_3"], show_alert=True)
        await callback.answer()
        await music_on(chat_id)
        await VISHAL.resume_stream(chat_id)
        await callback.message.reply_text(
            text=_["admin_4"].format(user_mention),
            reply_markup=buttons_to_inline_markup(close_markup(_)),
        )

    elif command in ["Stop", "End"]:
        await callback.answer()
        await VISHAL.stop_stream(chat_id)
        await set_loop(chat_id, 0)
        await callback.message.reply_text(
            text=_["admin_5"].format(user_mention),
            reply_markup=buttons_to_inline_markup(close_markup(_)),
        )
        await callback.message.delete()

    elif command == "Mute":
        if await is_muted(chat_id):
            return await callback.answer(_["admin_45"], show_alert=True)
        await callback.answer()
        await mute_on(chat_id)
        await VISHAL.mute_stream(chat_id)
        await callback.message.reply_text(_["admin_46"].format(user_mention))

    elif command == "Unmute":
        if not await is_muted(chat_id):
            return await callback.answer(_["admin_47"], show_alert=True)
        await callback.answer()
        await mute_off(chat_id)
        await VISHAL.unmute_stream(chat_id)
        await callback.message.reply_text(_["admin_48"].format(user_mention))

    elif command == "Loop":
        await callback.answer()
        await set_loop(chat_id, 3)
        await callback.message.reply_text(_["admin_41"].format(user_mention, 3))

    elif command == "Shuffle":
        playlist = db.get(chat_id)
        if not playlist or not isinstance(playlist, list):
            return await callback.answer(_["admin_42"], show_alert=True)
        try:
            popped = playlist.pop(0) if len(playlist) > 0 else None
            if popped is None:
                return await callback.answer(_["admin_43"], show_alert=True)
        except Exception:
            return await callback.answer(_["admin_43"], show_alert=True)
        if not playlist:
            playlist.insert(0, popped)
            return await callback.answer(_["admin_43"], show_alert=True)
        await callback.answer()
        random.shuffle(playlist)
        playlist.insert(0, popped)
        await callback.message.reply_text(_["admin_44"].format(user_mention))

    elif command in ["Skip", "Replay"]:
        await handle_skip_replay(callback, _, chat_id, command, user_mention)

    else:
        await handle_seek(callback, _, chat_id, command, user_mention)


async def _colored_reply_photo(callback, photo, caption, buttons, db_ref, chat_id, markup_type):
    """Send a photo reply with colored buttons via smart wrapper."""
    run = await send_photo_colored(
        chat_id=callback.message.chat.id,
        photo=photo,
        caption=caption,
        reply_markup=buttons,
    )
    playlist = db.get(chat_id)
    if playlist and len(playlist) > 0:
        playlist[0]["mystic"] = run
        playlist[0]["markup"] = markup_type
        playlist[0]["base_caption"] = caption
    return run


async def handle_skip_replay(callback: CallbackQuery, _, chat_id: int, command: str, user_mention: str):
    playlist = db.get(chat_id)
    if not playlist or not isinstance(playlist, list):
        return await callback.answer(_["queue_2"], show_alert=True)

    if command == "Skip":
        text_msg = f"➻ sᴛʀᴇᴀᴍ sᴋɪᴩᴩᴇᴅ 🎄\n│ \n└ʙʏ : {user_mention} 🥀"
        try:
            popped = playlist.pop(0) if len(playlist) > 0 else None
            if popped:
                await auto_clean(popped)
            if not playlist or len(playlist) == 0:
                if await is_autoplay_on(chat_id):
                    try:
                        await VISHAL.stop_stream(chat_id)
                        from VISHALMUSIC.utils.database import remove_active_chat, remove_active_video_chat
                        await remove_active_chat(chat_id)
                        await remove_active_video_chat(chat_id)
                        from VISHALMUSIC.utils.stream.autoplay import auto_play_next
                        await auto_play_next(
                            chat_id,
                            popped.get("chat_id", chat_id) if popped else chat_id,
                            popped.get("title", "") if popped else "",
                            popped.get("vidid", "") if popped else "",
                        )
                        await callback.edit_message_text(text_msg)
                        return
                    except Exception:
                        pass
                await callback.edit_message_text(text_msg)
                await callback.message.reply_text(
                    text=_["admin_6"].format(user_mention, callback.message.chat.title),
                    reply_markup=buttons_to_inline_markup(close_markup(_)),
                )
                return await VISHAL.stop_stream(chat_id)
        except Exception:
            try:
                await callback.edit_message_text(text_msg)
                await callback.message.reply_text(
                    text=_["admin_6"].format(user_mention, callback.message.chat.title),
                    reply_markup=buttons_to_inline_markup(close_markup(_)),
                )
                return await VISHAL.stop_stream(chat_id)
            except Exception:
                return
    else:
        text_msg = f"➻ sᴛʀᴇᴀᴍ ʀᴇ-ᴘʟᴀʏᴇᴅ 🎄\n│ \n└ʙʏ : {user_mention} 🥀"

    await callback.answer()

    if not playlist or len(playlist) == 0:
        return await callback.answer(_["queue_2"], show_alert=True)

    current_track = playlist[0]
    queued = current_track.get("file")
    title = (current_track.get("title", "")).title()
    user = current_track.get("by", "")
    duration = current_track.get("dur", "")
    streamtype = current_track.get("streamtype", "")
    videoid = current_track.get("vidid", "")
    status = True if str(streamtype) == "video" else None

    if db.get(chat_id) and len(db[chat_id]) > 0:
        db[chat_id][0]["played"] = 0
        if current_track.get("old_dur"):
            db[chat_id][0]["dur"] = current_track["old_dur"]
            db[chat_id][0]["seconds"] = current_track.get("old_second", 0)
            db[chat_id][0]["speed_path"] = None
            db[chat_id][0]["speed"] = 1.0

    ap_status = await is_autoplay_on(chat_id)

    if "live_" in queued:
        n, new_link = await YouTube.video(videoid, True)
        if n == 0:
            return await send_message_colored(
                callback.message.chat.id,
                _["admin_7"].format(title),
                reply_markup=close_markup(_),
            )
        try:
            image = await YouTube.thumbnail(videoid, True)
        except Exception:
            image = None
        try:
            await VISHAL.skip_stream(chat_id, new_link, video=status, image=image)
        except Exception:
            return await callback.message.reply_text(_["call_6"])
        buttons = colored_stream_markup(_, chat_id, autoplay_status=ap_status)
        img = await get_thumb(videoid)
        await _colored_reply_photo(
            callback, img,
            _["stream_1"].format(f"https://t.me/{app.username}?start=info_{videoid}", title[:23], duration, user),
            buttons, None, chat_id, "tg",
        )
        await edit_message_text_colored(callback.message.chat.id, callback.message.id, text_msg, reply_markup=close_markup(_))

    elif "vid_" in queued:
        mystic = await callback.message.reply_text(_["call_7"], disable_web_page_preview=True)
        
        # Retry logic for YouTube download failures
        max_retries = 3
        download_success = False
        file_path = None
        direct = False

        for attempt in range(max_retries):
            try:
                file_path, direct = await YouTube.download(videoid, mystic, videoid=True, video=status)
                if file_path:
                    download_success = True
                    break
            except Exception:
                if attempt < max_retries - 1:
                    continue
                else:
                    return await edit_message_text_colored(chat_id=mystic.chat.id, message_id=mystic.id, text=_["call_6"])

        if not download_success or not file_path:
            return await edit_message_text_colored(chat_id=mystic.chat.id, message_id=mystic.id, text=_["call_6"])
        try:
            image = await YouTube.thumbnail(videoid, True)
        except Exception:
            image = None
        try:
            await VISHAL.skip_stream(chat_id, file_path, video=status, image=image)
        except Exception:
            return await edit_message_text_colored(chat_id=mystic.chat.id, message_id=mystic.id, text=_["call_6"])
        buttons = colored_stream_markup(_, chat_id, autoplay_status=ap_status)
        img = await get_thumb(videoid)
        await _colored_reply_photo(
            callback, img,
            _["stream_1"].format(f"https://t.me/{app.username}?start=info_{videoid}", title[:23], duration, user),
            buttons, None, chat_id, "stream",
        )
        await edit_message_text_colored(callback.message.chat.id, callback.message.id, text_msg, reply_markup=close_markup(_))
        await mystic.delete()

    elif "index_" in queued:
        try:
            await VISHAL.skip_stream(chat_id, videoid, video=status)
        except Exception:
            return await callback.message.reply_text(_["call_6"])
        buttons = colored_stream_markup(_, chat_id, autoplay_status=ap_status)
        await _colored_reply_photo(callback, STREAM_IMG_URL, _["stream_2"].format(user), buttons, None, chat_id, "tg")
        await edit_message_text_colored(callback.message.chat.id, callback.message.id, text_msg, reply_markup=close_markup(_))

    else:
        if videoid in ["telegram", "soundcloud"]:
            image = None
        else:
            try:
                image = await YouTube.thumbnail(videoid, True)
            except Exception:
                image = None
        try:
            await VISHAL.skip_stream(chat_id, queued, video=status, image=image)
        except Exception:
            return await callback.message.reply_text(_["call_6"])
        if videoid == "telegram":
            buttons = colored_stream_markup(_, chat_id, autoplay_status=ap_status)
            photo = TELEGRAM_AUDIO_URL if str(streamtype) == "audio" else TELEGRAM_VIDEO_URL
            await _colored_reply_photo(
                callback, photo,
                _["stream_1"].format(SUPPORT_CHAT, title[:23], duration, user),
                buttons, None, chat_id, "tg",
            )
        elif videoid == "soundcloud":
            buttons = colored_stream_markup(_, chat_id, autoplay_status=ap_status)
            photo = SOUNCLOUD_IMG_URL if str(streamtype) == "audio" else TELEGRAM_VIDEO_URL
            await _colored_reply_photo(
                callback, photo,
                _["stream_1"].format(SUPPORT_CHAT, title[:23], duration, user),
                buttons, None, chat_id, "tg",
            )
        else:
            buttons = colored_stream_markup(_, chat_id, autoplay_status=ap_status)
            img = await get_thumb(videoid)
            await _colored_reply_photo(
                callback, img,
                _["stream_1"].format(f"https://t.me/{app.username}?start=info_{videoid}", title[:23], duration, user),
                buttons, None, chat_id, "stream",
            )
        await edit_message_text_colored(callback.message.chat.id, callback.message.id, text_msg, reply_markup=close_markup(_))


async def handle_seek(callback: CallbackQuery, _, chat_id: int, command: str, user_mention: str):
    playing = db.get(chat_id)
    if not playing or not isinstance(playing, list) or len(playing) == 0:
        return await callback.answer(_["queue_2"], show_alert=True)
    
    current_track = playing[0]
    duration_seconds = int(current_track.get("seconds", 0))
    if duration_seconds == 0:
        return await callback.answer(_["admin_22"], show_alert=True)
    file_path = current_track.get("file")
    if not file_path:
        return await callback.answer(_["admin_22"], show_alert=True)
    if "index_" in file_path or "live_" in file_path:
        return await callback.answer(_["admin_22"], show_alert=True)
    duration_played = int(current_track.get("played", 0))
    duration_to_skip = 10 if int(command) in [1, 2] else 30
    duration = current_track.get("dur", "")
    if int(command) in [1, 3]:
        if (duration_played - duration_to_skip) <= 10:
            bet = seconds_to_min(duration_played)
            return await callback.answer(
                f"» ʙᴏᴛ ɪs ᴜɴᴀʙʟᴇ ᴛᴏ sᴇᴇᴋ ʙᴇᴄᴀᴜsᴇ ᴛʜᴇ ᴅᴜʀᴀᴛɪᴏɴ ᴇxᴄᴇᴇᴅs.\n\n"
                f"ᴄᴜʀʀᴇɴᴛʟʏ ᴩʟᴀʏᴇᴅ :** {bet}** ᴍɪɴᴜᴛᴇs ᴏᴜᴛ ᴏғ **{duration}** ᴍɪɴᴜᴛᴇs.",
                show_alert=True,
            )
        to_seek = duration_played - duration_to_skip + 1
    else:
        if (duration_seconds - (duration_played + duration_to_skip)) <= 10:
            bet = seconds_to_min(duration_played)
            return await callback.answer(
                f"» ʙᴏᴛ ɪs ᴜɴᴀʙʟᴇ ᴛᴏ sᴇᴇᴋ ʙᴇᴄᴀᴜsᴇ ᴛʜᴇ ᴅᴜʀᴀᴛɪᴏɴ ᴇxᴄᴇᴇᴅs.\n\n"
                f"ᴄᴜʀʀᴇɴᴛʟʏ ᴩʟᴀʏᴇᴅ :** {bet}** ᴍɪɴᴜᴛᴇs ᴏᴜᴛ ᴏғ **{duration}** ᴍɪɴᴜᴛᴇs.",
                show_alert=True,
            )
        to_seek = duration_played + duration_to_skip + 1

    await callback.answer()
    mystic = await callback.message.reply_text(_["admin_24"])
    if "vid_" in file_path:
        n, file_path = await YouTube.video(current_track.get("vidid", ""), True)
        if n == 0:
            return await edit_message_text_colored(chat_id=mystic.chat.id, message_id=mystic.id, text=_["admin_22"])
    try:
        await VISHAL.seek_stream(
            chat_id,
            file_path,
            seconds_to_min(to_seek),
            duration,
            current_track.get("streamtype", ""),
        )
    except Exception:
        return await edit_message_text_colored(chat_id=mystic.chat.id, message_id=mystic.id, text=_["admin_26"])
    if db.get(chat_id) and len(db[chat_id]) > 0:
        if int(command) in [1, 3]:
            db[chat_id][0]["played"] -= duration_to_skip
        else:
            db[chat_id][0]["played"] += duration_to_skip
    seek_message = _["admin_25"].format(seconds_to_min(to_seek))
    await edit_message_text_colored(chat_id=mystic.chat.id, message_id=mystic.id, text=f"{seek_message}\n\nᴄʜᴀɴɢᴇs ᴅᴏɴᴇ ʙʏ : {user_mention} !")


@app.on_callback_query(filters.regex("^close$") & ~BANNED_USERS)
async def close_menu(_, query: CallbackQuery):
    try:
        await query.answer()
        await query.message.delete()
        msg = await query.message.reply_text(f"✅ ᴄʟᴏꜱᴇᴅ ʙʏ : {query.from_user.mention}")
        await asyncio.sleep(2)
        await msg.delete()
    except Exception:
        pass


@app.on_callback_query(filters.regex("stop_downloading") & ~BANNED_USERS)
@ActualAdminCB
async def stop_download(_, query: CallbackQuery, _lang):
    task = lyrical.get(query.message.id)
    if not task:
        return await query.answer(_lang["tg_4"], show_alert=True)
    if task.done() or task.cancelled():
        return await query.answer(_lang["tg_5"], show_alert=True)
    try:
        task.cancel()
        lyrical.pop(query.message.id, None)
        await query.answer(_lang["tg_6"], show_alert=True)
        return await query.edit_message_text(_lang["tg_7"].format(query.from_user.mention))
    except Exception:
        return await query.answer(_lang["tg_8"], show_alert=True)


async def _now_playing_timer():
    """
    Unified background task: updates caption + inline buttons in ONE single
    editMessageCaption call every UPDATE_INTERVAL seconds.

    Using a single API call instead of two separate edits (editMessageCaption +
    editMessageReplyMarkup) prevents the flicker/blink that users see when the
    message is edited twice in quick succession.
    """
    from VISHALMUSIC.utils.inline.play import UPDATE_INTERVAL, should_update_progress

    # FIX: "message is not modified" spam se bachne ke liye — agar caption +
    # buttons content pehle wale jaisa hi ho toh API call skip karo.
    _last_sent = {}  # chat_id -> fingerprint

    while True:
        await asyncio.sleep(UPDATE_INTERVAL)
        active_chats = await get_active_chats()
        for chat_id in active_chats:
            try:
                playing = db.get(chat_id)
                if not playing or not isinstance(playing, list) or len(playing) == 0:
                    continue
                track = playing[0]
                mystic = track.get("mystic")
                base_caption = track.get("base_caption")
                if not mystic or not base_caption:
                    continue

                # Resolve message coordinates
                if isinstance(mystic, dict):
                    m_chat_id = (mystic.get("chat") or {}).get("id")
                    m_id = mystic.get("message_id")
                else:
                    m_chat_id = getattr(getattr(mystic, "chat", None), "id", None)
                    m_id = getattr(mystic, "id", None)
                if not m_chat_id or not m_id:
                    continue

                played = track.get("played", 0)
                dur = track.get("dur", "0:00")
                dur_sec = time_to_seconds(dur)
                if dur_sec == 0:
                    continue

                played_sec = played if isinstance(played, int) else time_to_seconds(str(played))
                bar = generate_progress_bar(played_sec, dur_sec)
                played_str = seconds_to_min(played_sec)

                # Build updated caption WITHOUT progress bar (progress bar is in inline button)
                new_caption = base_caption

                # Build updated inline buttons (rate-limited inside should_update_progress)
                _lang = get_string(await get_lang(chat_id))
                ap_status = await is_autoplay_on(chat_id)
                buttons = colored_stream_markup_timer(
                    _lang,
                    chat_id,
                    played_str,
                    dur,
                    autoplay_status=ap_status,
                )

                from pyrogram import enums

                # FIX: content same hai toh edit hi mat karo (not-modified spam)
                fp = (new_caption, played_str, dur, ap_status, len(buttons or []))
                if _last_sent.get(chat_id) == fp:
                    continue
                _last_sent[chat_id] = fp

                if buttons:
                    # Try Bot API first (colored buttons persist)
                    api_ok = False
                    try:
                        result = await edit_message_caption_colored(
                            chat_id=m_chat_id,
                            message_id=m_id,
                            caption=new_caption,
                            reply_markup=buttons,
                        )
                        api_ok = bool(result)
                    except Exception:
                        api_ok = False

                    # Fallback: direct Pyrogram edit (no colors, HTML parsed)
                    if not api_ok and not isinstance(mystic, dict):
                        try:
                            await mystic.edit_caption(
                                caption=new_caption,
                                parse_mode=enums.ParseMode.HTML,
                                reply_markup=buttons_to_inline_markup(buttons),
                            )
                        except Exception:
                            pass
                else:
                    # Timer throttled — only update caption (no markup change)
                    if not isinstance(mystic, dict):
                        try:
                            await mystic.edit_caption(
                                caption=new_caption,
                                parse_mode=enums.ParseMode.HTML,
                            )
                        except Exception:
                            pass
            except Exception:
                continue


asyncio.create_task(_now_playing_timer())

# ═══════════════════════════════════════════════════════════
#        😎  KRISH X STAR MUSIC BOT  😎
#   t.me/iwanthotpinkpussy
# ═══════════════════════════════════════════════════════════
