# ═══════════════════════════════════════════════════════════
#        😎  KRISH X STAR MUSIC BOT  😎
#   GitHub : t.me/iwanthotpinkpussy
#   Developer : @iwanthotpinkpussy | Telegram
#   Module : Sudo User Management
# ═══════════════════════════════════════════════════════════

from pyrogram import filters
from pyrogram.types import CallbackQuery, Message

from config import BANNED_USERS, OWNER_ID
from VISHALMUSIC import app
from VISHALMUSIC.misc import SUDOERS
from VISHALMUSIC.utils.colored_buttons import styled_button, buttons_to_inline_markup, send_message_colored, edit_message_caption_colored
from VISHALMUSIC.utils.database import add_sudo, remove_sudo
from VISHALMUSIC.utils.decorators.language import language
from VISHALMUSIC.utils.formatters import extract_user

# ─── Add Sudo ─────────────────────────────────────────────

@app.on_message(filters.command(["addsudo"], prefixes=["/", "!", "."]) & filters.user(OWNER_ID))
@language
async def add_sudo_user(client, message: Message, _):
    if not message.reply_to_message and len(message.command) != 2:
        return await message.reply_text(_["general_1"])

    user = await extract_user(message)
    if user.id in SUDOERS:
        return await message.reply_text(_["sudo_1"].format(user.mention))

    if await add_sudo(user.id):
        if user.id not in SUDOERS:
            SUDOERS.add(user.id)
        return await message.reply_text(_["sudo_2"].format(user.mention))

    await message.reply_text(_["sudo_8"])

# ─── Remove Sudo ───────────────────────────────────────────

@app.on_message(filters.command(["delsudo", "rmsudo"], prefixes=["/", "!", "."]) & filters.user(OWNER_ID))
@language
async def remove_sudo_user(client, message: Message, _):
    if not message.reply_to_message and len(message.command) != 2:
        return await message.reply_text(_["general_1"])

    user = await extract_user(message)
    if user.id not in SUDOERS:
        return await message.reply_text(_["sudo_3"].format(user.mention))

    if await remove_sudo(user.id):
        if user.id in SUDOERS:
            SUDOERS.remove(user.id)
        return await message.reply_text(_["sudo_4"].format(user.mention))

    await message.reply_text(_["sudo_8"])

# ─── Sudo List Entry ───────────────────────────────────────

@app.on_message(filters.command(["sudolist", "listsudo", "sudoers"], prefixes=["/", "!", "."]) & ~BANNED_USERS)
async def sudoers_list(client, message: Message):
    buttons = [[styled_button("๏ ᴠɪᴇᴡ sᴜᴅᴏʟɪsᴛ ๏", callback_data="sudo_list_view", style="primary")]]

    await send_message_colored(
        chat_id=message.chat.id,
        text="**» ᴄʜᴇᴄᴋ sᴜᴅᴏ ʟɪsᴛ ʙʏ ɢɪᴠᴇɴ ʙᴇʟᴏᴡ ʙᴜᴛᴛᴏɴ.**\n\n**» ɴᴏᴛᴇ:**  ᴏɴʟʏ sᴜᴅᴏ ᴜsᴇʀs ᴄᴀɴ ᴠɪᴇᴡ.",
        reply_markup=buttons
    )

# ─── Callback: View Sudo List ──────────────────────────────

@app.on_callback_query(filters.regex("^sudo_list_view$"))
async def view_sudo_list_callback(client, callback_query: CallbackQuery):
    if callback_query.from_user.id not in SUDOERS:
        return await callback_query.answer("ᴏɴʟʏ sᴜᴅᴏᴇʀs ᴀɴᴅ ᴏᴡɴᴇʀ ᴄᴀɴ ᴀᴄᴄᴇss ᴛʜɪs", show_alert=True)

    owner = await app.get_users(OWNER_ID)
    caption = f"**˹ʟɪsᴛ ᴏғ ʙᴏᴛ ᴍᴏᴅᴇʀᴀᴛᴏʀs˼**\n\n**🌹Oᴡɴᴇʀ** ➥ {owner.mention}\n\n"
    buttons = [[styled_button("๏ ᴠɪᴇᴡ ᴏᴡɴᴇʀ ๏", url=f"tg://openmessage?user_id={OWNER_ID}", style="primary")]]

    count = 0
    for user_id in SUDOERS:
        if user_id == OWNER_ID:
            continue
        try:
            user = await app.get_users(user_id)
            count += 1
            caption += f"**🎁 Sᴜᴅᴏ {count} »** {user.mention}\n"
            buttons.append([
                styled_button(f"๏ ᴠɪᴇᴡ sᴜᴅᴏ {count} ๏", url=f"tg://openmessage?user_id={user_id}", style="primary")
            ])
        except Exception:
            continue

    if count == 0:
        caption += "_No additional sudoers yet._"

    buttons.append([styled_button("๏ ʙᴀᴄᴋ ๏", callback_data="sudo_list_back", style="primary")])
    await edit_message_caption_colored(chat_id=callback_query.message.chat.id, message_id=callback_query.message.id, caption=caption, reply_markup=buttons)

# ─── Callback: Back to List Menu ────────────────────────────

@app.on_callback_query(filters.regex("^sudo_list_back$"))
async def back_to_sudo_list_menu(client, callback_query: CallbackQuery):
    buttons = [[styled_button("๏ ᴠɪᴇᴡ sᴜᴅᴏʟɪsᴛ ๏", callback_data="sudo_list_view", style="primary")]]
    await edit_message_caption_colored(
        chat_id=callback_query.message.chat.id,
        message_id=callback_query.message.id,
        caption="**» ᴄʜᴇᴄᴋ sᴜᴅᴏ ʟɪsᴛ ʙʏ ɢɪᴠᴇɴ ʙᴇʟᴏᴡ ʙᴜᴛᴛᴏɴ.**\n\n**» ɴᴏᴛᴇ:**  ᴏɴʟʏ sᴜᴅᴏ ᴜsᴇʀs ᴄᴀɴ ᴠɪᴇᴡ.",
        reply_markup=buttons
    )

# ─── Delete All Sudo ───────────────────────────────────────

@app.on_message(filters.command("delallsudo", prefixes=["/", "!", "%", ",", ".", "@", "#"]) & filters.user(OWNER_ID))
@language
async def remove_all_sudo_users(client, message: Message, _):
    removed_count = 0
    for user_id in list(SUDOERS):
        if user_id != OWNER_ID:
            if await remove_sudo(user_id):
                if user_id in SUDOERS:
                    SUDOERS.remove(user_id)
                removed_count += 1
    await message.reply_text(f"Removed {removed_count} users from the sudo list.")

# ═══════════════════════════════════════════════════════════
#        😎  KRISH X STAR MUSIC BOT  😎
#   t.me/iwanthotpinkpussy
# ═══════════════════════════════════════════════════════════
