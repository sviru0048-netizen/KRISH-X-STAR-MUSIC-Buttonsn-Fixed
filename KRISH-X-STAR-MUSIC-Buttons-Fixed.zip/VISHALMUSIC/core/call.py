# ═══════════════════════════════════════════════════════════
#        😎  KRISH X STAR MUSIC BOT  😎
#   GitHub : t.me/iwanthotpinkpussy
#   Developer : @iwanthotpinkpussy | Telegram
#   Module : Voice Chat Call Handler & Stream Manager
# ═══════════════════════════════════════════════════════════

import asyncio
import logging
import os
import traceback
from datetime import datetime, timedelta
from typing import Union

from ntgcalls import TelegramServerError
from pyrogram import Client
from pyrogram.errors import FloodWait, ChatAdminRequired
from pytgcalls import PyTgCalls
from pytgcalls.exceptions import NoActiveGroupCall
from pytgcalls.types import AudioQuality, ChatUpdate, MediaStream, StreamEnded, Update, VideoQuality

import config
from strings import get_string
from VISHALMUSIC import LOGGER, YouTube, app
from VISHALMUSIC.misc import db
from VISHALMUSIC.utils.stream.autoplay import is_autoplay_on
from VISHALMUSIC.utils.database import (
    add_active_chat,
    add_active_video_chat,
    get_lang,
    get_loop,
    group_assistant,
    is_autoend,
    music_on,
    remove_active_chat,
    remove_active_video_chat,
    set_loop,
)
from VISHALMUSIC.utils.exceptions import AssistantErr
from VISHALMUSIC.utils.formatters import check_duration, seconds_to_min, speed_converter
from VISHALMUSIC.utils.inline.play import colored_stream_markup, colored_stream_markup_timer
from VISHALMUSIC.utils.colored_buttons import buttons_to_inline_markup, smart_send_photo
from VISHALMUSIC.utils.stream.autoclear import auto_clean

logger = logging.getLogger(__name__)
from VISHALMUSIC.utils.thumbnails import get_thumb, get_thumb_url
from VISHALMUSIC.utils.errors import capture_internal_err, send_large_error
from VISHALMUSIC.utils.pastebin import VISHALBIN

autoend = {}
counter = {}

def dynamic_media_stream(path: str, video: bool = False, ffmpeg_params: str = None) -> MediaStream:
    return MediaStream(
        audio_path=path,
        media_path=path,
        audio_parameters=AudioQuality.STUDIO,
        video_parameters=VideoQuality.HD_720p if video else VideoQuality.SD_360p,
        video_flags=(MediaStream.Flags.AUTO_DETECT if video else MediaStream.Flags.IGNORE),
        ffmpeg_parameters=ffmpeg_params,
    )

async def _colored_send_photo(original_chat_id, photo, caption, buttons, db_ref, chat_id, markup_type):
    """Send photo with colored buttons via smart wrapper (auto fallback)."""
    run = await smart_send_photo(
        chat_id=original_chat_id,
        photo=photo,
        caption=caption,
        reply_markup=buttons,
    )
    playlist = db.get(chat_id)
    if playlist and len(playlist) > 0:
        playlist[0]["mystic"] = run
        playlist[0]["markup"] = markup_type
        playlist[0]["base_caption"] = caption
    return run


async def _clear_(chat_id: int) -> None:
    popped = db.pop(chat_id, None)
    if popped:
        await auto_clean(popped)
    db[chat_id] = []
    await remove_active_video_chat(chat_id)
    await remove_active_chat(chat_id)
    await set_loop(chat_id, 0)

class Call:
    def __init__(self):
        self.userbot1 = Client(
            "VishalXAssis1", config.API_ID, config.API_HASH, session_string=config.STRING1, sleep_threshold=60
        ) if config.STRING1 else None
        self.one = PyTgCalls(self.userbot1) if self.userbot1 else None

        self.userbot2 = Client(
            "VishalXAssis2", config.API_ID, config.API_HASH, session_string=config.STRING2, sleep_threshold=60
        ) if config.STRING2 else None
        self.two = PyTgCalls(self.userbot2) if self.userbot2 else None

        self.userbot3 = Client(
            "VishalXAssis3", config.API_ID, config.API_HASH, session_string=config.STRING3, sleep_threshold=60
        ) if config.STRING3 else None
        self.three = PyTgCalls(self.userbot3) if self.userbot3 else None

        self.userbot4 = Client(
            "VishalXAssis4", config.API_ID, config.API_HASH, session_string=config.STRING4, sleep_threshold=60
        ) if config.STRING4 else None
        self.four = PyTgCalls(self.userbot4) if self.userbot4 else None

        self.userbot5 = Client(
            "VishalXAssis5", config.API_ID, config.API_HASH, session_string=config.STRING5, sleep_threshold=60
        ) if config.STRING5 else None
        self.five = PyTgCalls(self.userbot5) if self.userbot5 else None

        self.active_calls: set[int] = set()


    @capture_internal_err
    async def pause_stream(self, chat_id: int) -> None:
        assistant = await group_assistant(self, chat_id)
        await assistant.pause(chat_id)

    @capture_internal_err
    async def resume_stream(self, chat_id: int) -> None:
        assistant = await group_assistant(self, chat_id)
        await assistant.resume(chat_id)

    @capture_internal_err
    async def mute_stream(self, chat_id: int) -> None:
        assistant = await group_assistant(self, chat_id)
        await assistant.mute(chat_id)

    @capture_internal_err
    async def unmute_stream(self, chat_id: int) -> None:
        assistant = await group_assistant(self, chat_id)
        await assistant.unmute(chat_id)

    @capture_internal_err
    async def stop_stream(self, chat_id: int) -> None:
        assistant = await group_assistant(self, chat_id)
        await _clear_(chat_id)
        if chat_id not in self.active_calls:
            return
        try:
            await assistant.leave_call(chat_id)
        except Exception:
            pass
        finally:
            self.active_calls.discard(chat_id)


    @capture_internal_err
    async def force_stop_stream(self, chat_id: int) -> None:
        assistant = await group_assistant(self, chat_id)
        try:
            check = db.get(chat_id)
            if check:
                check.pop(0)
        except (IndexError, KeyError):
            pass
        await remove_active_video_chat(chat_id)
        await remove_active_chat(chat_id)
        await _clear_(chat_id)
        if chat_id not in self.active_calls:
            return
        try:
            await assistant.leave_call(chat_id)
        except Exception:
            pass
        finally:
            self.active_calls.discard(chat_id)


    @capture_internal_err
    async def skip_stream(self, chat_id: int, link: str, video: Union[bool, str] = None, image: Union[bool, str] = None) -> None:
        assistant = await group_assistant(self, chat_id)
        stream = dynamic_media_stream(path=link, video=bool(video))
        await assistant.play(chat_id, stream)

    @capture_internal_err
    async def vc_users(self, chat_id: int) -> list:
        assistant = await group_assistant(self, chat_id)
        participants = await assistant.get_participants(chat_id)
        return [p.user_id for p in participants if not p.is_muted]

    @capture_internal_err
    async def seek_stream(self, chat_id: int, file_path: str, to_seek: str, duration: str, mode: str) -> None:
        assistant = await group_assistant(self, chat_id)
        ffmpeg_params = f"-ss {to_seek} -to {duration}"
        is_video = mode == "video"
        stream = dynamic_media_stream(path=file_path, video=is_video, ffmpeg_params=ffmpeg_params)
        await assistant.play(chat_id, stream)

    @capture_internal_err
    async def speedup_stream(self, chat_id: int, file_path: str, speed: float, playing: list) -> None:
        if not isinstance(playing, list) or not playing or not isinstance(playing[0], dict):
            raise AssistantErr("Invalid stream info for speedup.")

        assistant = await group_assistant(self, chat_id)
        base = os.path.basename(file_path)
        chatdir = os.path.join("playback", str(speed))
        os.makedirs(chatdir, exist_ok=True)
        out = os.path.join(chatdir, base)

        if not os.path.exists(out):
            vs = str(2.0 / float(speed))
            cmd = f'ffmpeg -i "{file_path}" -filter:v setpts={vs}*PTS -filter:a atempo={speed} "{out}"'
            proc = await asyncio.create_subprocess_shell(cmd, stdin=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE)
            await proc.communicate()

        dur = int(await asyncio.get_event_loop().run_in_executor(None, check_duration, out))
        played, con_seconds = speed_converter(playing[0]["played"], speed)
        duration_min = seconds_to_min(dur)
        is_video = playing[0]["streamtype"] == "video"
        ffmpeg_params = f"-ss {played} -to {duration_min}"
        stream = dynamic_media_stream(path=out, video=is_video, ffmpeg_params=ffmpeg_params)

        if chat_id in db and db[chat_id] and db[chat_id][0].get("file") == file_path:
            await assistant.play(chat_id, stream)
        else:
            raise AssistantErr("Stream mismatch during speedup.")

        db[chat_id][0].update({
            "played": con_seconds,
            "dur": duration_min,
            "seconds": dur,
            "speed_path": out,
            "speed": speed,
            "old_dur": db[chat_id][0].get("dur"),
            "old_second": db[chat_id][0].get("seconds"),
        })


    @capture_internal_err
    async def stream_call(self, link: str) -> None:
        assistant = await group_assistant(self, config.LOGGER_ID)
        try:
            await assistant.play(config.LOGGER_ID, MediaStream(link))
            await asyncio.sleep(8)
        finally:
            try:
                await assistant.leave_call(config.LOGGER_ID)
            except:
                pass

    @capture_internal_err
    async def join_call(
        self,
        chat_id: int,
        original_chat_id: int,
        link: str,
        video: Union[bool, str] = None,
        image: Union[bool, str] = None,
    ) -> None:
        assistant = await group_assistant(self, chat_id)
        lang = await get_lang(chat_id)
        _ = get_string(lang)
        stream = dynamic_media_stream(path=link, video=bool(video))

        try:
            await assistant.play(chat_id, stream)
        except (NoActiveGroupCall, ChatAdminRequired):
            raise AssistantErr(_["call_8"])
        except TelegramServerError:
            raise AssistantErr(_["call_10"])
        except Exception as e:
            raise AssistantErr(
                f"ᴜɴᴀʙʟᴇ ᴛᴏ ᴊᴏɪɴ ᴛʜᴇ ɢʀᴏᴜᴘ ᴄᴀʟʟ.\nRᴇᴀsᴏɴ: {e}"
            )
        self.active_calls.add(chat_id)
        await add_active_chat(chat_id)
        await music_on(chat_id)
        if video:
            await add_active_video_chat(chat_id)

        if await is_autoend():
            counter[chat_id] = {}
            users = len(await assistant.get_participants(chat_id))
            if users == 1:
                autoend[chat_id] = datetime.now() + timedelta(minutes=1)


    @capture_internal_err
    async def play(self, client, chat_id: int) -> None:
        check = db.get(chat_id)
        popped = None
        loop = await get_loop(chat_id)
        try:
            # Check if check exists and has items before accessing
            if not check or not isinstance(check, list):
                return
            if loop == 0:
                if len(check) == 0:
                    return
                popped = check.pop(0)
            else:
                loop = loop - 1
                await set_loop(chat_id, loop)
            await auto_clean(popped)
            if not check or not isinstance(check, list) or len(check) == 0:
                # Store popped data BEFORE _clear_() because _clear_() wipes db[chat_id]
                last_title = popped.get("title", "") if popped else ""
                last_vidid = popped.get("vidid", "") if popped else ""
                last_chat_id = popped.get("chat_id", chat_id) if popped else chat_id
                last_video = (popped.get("streamtype") == "video") if popped else False

            # _clear_() marks the chat inactive in DB (is_active_chat()=False).
            # This is intentional: stream() inside auto_play_next() checks
            # is_active_chat() to decide whether to "just queue" or to
            # actually download + join_call + play. We NEED it to be False
            # here so stream() takes the "start fresh" path and calls
            # join_call() → assistant.play() to start the new stream.
            # (If is_active_chat() were True, stream() would only add
            # the song to queue without playing it — nothing would start.)
            await _clear_(chat_id)

            autoplay_started = False
            # ── QUEUE FIX ──────────────────────────────────────────────
            # Queue me aur songs hain toh autoplay/leave ko SKIP karke
            # niche "else" branch me jao jo agla queued song play karta hai.
            # Autoplay sirf tab chahiye jab queue KHAALI ho; VC leave sirf
            # tab jab queue bhi khaali aur autoplay bhi ON na ho.
            queue_remaining = check and isinstance(check, list) and len(check) > 0

            if not queue_remaining:
                if last_title and await is_autoplay_on(chat_id):
                    try:
                        from VISHALMUSIC.utils.stream.autoplay import auto_play_next
                        from VISHALMUSIC.utils.database import is_active_chat as _is_chat_active

                        autoplay_started = await auto_play_next(
                            chat_id,
                            last_chat_id,
                            last_title,
                            last_vidid,
                            video=last_video,
                        )

                        # Verify the stream actually started.
                        # auto_play_next() can return True even when stream()
                        # silently failed — join_call() has @capture_internal_err
                        # which swallows its internal AssistantErr and returns
                        # None. stream() then still runs put_queue() and sends
                        # a "now playing" photo, but nothing is actually playing.
                        # A successful join_call() always calls add_active_chat(),
                        # so is_active_chat()=False means the join silently failed.
                        if autoplay_started and not await _is_chat_active(chat_id):
                            autoplay_started = False

                    except Exception:
                        autoplay_started = False

                # Queue khaali + autoplay ON nahi → tab hi VC leave
                if not autoplay_started and not await is_autoplay_on(chat_id):
                    if chat_id in self.active_calls:
                        try:
                            await client.leave_call(chat_id)
                        except NoActiveGroupCall:
                            pass
                        except Exception:
                            pass
                        finally:
                            self.active_calls.discard(chat_id)
                return
            # Queue me songs hain → "else" branch agla song play karega
        except:
            try:
                await _clear_(chat_id)
                return await client.leave_call(chat_id)
            except:
                return
        else:
            if not check or not isinstance(check, list) or len(check) == 0:
                return
            queued = check[0].get("file")
            if not queued:
                return
            # ── QUEUE FIX: db restore ──
            # _clear_() ne db[chat_id] = [] kar diya tha. Playing entry + baki
            # queue wapas set karo taaki agla StreamEnded agla song play kare
            # (chain continue ho). Beech me naye queued songs bhi preserve.
            db[chat_id] = check + (db.get(chat_id) or [])
            language = await get_lang(chat_id)
            _ = get_string(language)
            title = (check[0].get("title", "")).title()
            user = check[0].get("by", "")
            original_chat_id = check[0].get("chat_id", chat_id)
            streamtype = check[0].get("streamtype", "")
            videoid = check[0].get("vidid", "")
            if db.get(chat_id) and len(db[chat_id]) > 0:
                db[chat_id][0]["played"] = 0

            exis = check[0].get("old_dur") if check and len(check) > 0 else None
            if exis and db.get(chat_id) and len(db[chat_id]) > 0:
                db[chat_id][0]["dur"] = exis
                db[chat_id][0]["seconds"] = check[0].get("old_second") if check and len(check) > 0 else 0
                db[chat_id][0]["speed_path"] = None
                db[chat_id][0]["speed"] = 1.0

            video = True if str(streamtype) == "video" else False
            ap_status = await is_autoplay_on(chat_id)

            if "live_" in queued:
                n, link = await YouTube.video(videoid, True)
                if n == 0:
                    return await app.send_message(original_chat_id, text=_["call_6"])

                stream = dynamic_media_stream(path=link, video=video)
                try:
                    await client.play(chat_id, stream)
                except Exception:
                    return await app.send_message(original_chat_id, text=_["call_6"])

                img = await get_thumb_url(videoid)  # Use URL for colored buttons
                button = colored_stream_markup(_, chat_id, autoplay_status=ap_status)
                await _colored_send_photo(original_chat_id, img, _["stream_1"].format(
                        f"https://t.me/{app.username}?start=info_{videoid}",
                        title[:23],
                        check[0]["dur"],
                        user,
                    ), button, None, chat_id, "tg")

            elif "vid_" in queued:
                mystic = await app.send_message(original_chat_id, _["call_7"])
                
                # Retry logic for YouTube download failures
                max_retries = 3
                download_success = False
                file_path = None
                direct = False

                for attempt in range(max_retries):
                    try:
                        file_path, direct = await YouTube.download(
                            videoid,
                            mystic,
                            videoid=True,
                            video=True if str(streamtype) == "video" else False,
                        )
                        if file_path:
                            download_success = True
                            break
                    except:
                        if attempt < max_retries - 1:
                            continue
                        else:
                            return await mystic.edit_text(
                                _["call_6"], disable_web_page_preview=True
                            )

                if not download_success or not file_path:
                    return await mystic.edit_text(
                        _["call_6"], disable_web_page_preview=True
                    )

                stream = dynamic_media_stream(path=file_path, video=video)
                try:
                    await client.play(chat_id, stream)
                except:
                    return await app.send_message(original_chat_id, text=_["call_6"])

                img = await get_thumb_url(videoid)  # Use URL for colored buttons
                button = colored_stream_markup(_, chat_id, autoplay_status=ap_status)
                await mystic.delete()
                await _colored_send_photo(original_chat_id, img, _["stream_1"].format(
                        f"https://t.me/{app.username}?start=info_{videoid}",
                        title[:23],
                        check[0]["dur"],
                        user,
                    ), button, None, chat_id, "stream")

            elif "index_" in queued:
                stream = dynamic_media_stream(path=videoid, video=video)
                try:
                    await client.play(chat_id, stream)
                except:
                    return await app.send_message(original_chat_id, text=_["call_6"])

                button = colored_stream_markup(_, chat_id, autoplay_status=ap_status)
                await _colored_send_photo(original_chat_id, config.STREAM_IMG_URL, _["stream_2"].format(user), button, None, chat_id, "tg")

            else:
                stream = dynamic_media_stream(path=queued, video=video)
                try:
                    await client.play(chat_id, stream)
                except:
                    return await app.send_message(original_chat_id, text=_["call_6"])

                if videoid == "telegram":
                    button = colored_stream_markup(_, chat_id, autoplay_status=ap_status)
                    photo = config.TELEGRAM_AUDIO_URL if str(streamtype) == "audio" else config.TELEGRAM_VIDEO_URL
                    await _colored_send_photo(original_chat_id, photo, _["stream_1"].format(
                            config.SUPPORT_CHAT, title[:23], check[0]["dur"], user,
                        ), button, None, chat_id, "tg")

                elif videoid == "soundcloud":
                    button = colored_stream_markup(_, chat_id, autoplay_status=ap_status)
                    await _colored_send_photo(original_chat_id, config.SOUNCLOUD_IMG_URL, _["stream_1"].format(
                            config.SUPPORT_CHAT, title[:23], check[0]["dur"], user,
                        ), button, None, chat_id, "tg")

                else:
                    img = await get_thumb_url(videoid)  # Use URL for colored buttons
                    button = colored_stream_markup(_, chat_id, autoplay_status=ap_status)
                    caption = _["stream_1"].format(
                        f"https://t.me/{app.username}?start=info_{videoid}",
                        title[:23], check[0]["dur"], user,
                    )
                    try:
                        run = await smart_send_photo(
                            chat_id=original_chat_id,
                            photo=img,
                            caption=caption,
                            reply_markup=button,
                        )
                    except FloodWait as e:
                        LOGGER(__name__).warning(f"FloodWait: Sleeping for {e.value}")
                        await asyncio.sleep(e.value)
                        run = await smart_send_photo(
                            chat_id=original_chat_id,
                            photo=img,
                            caption=caption,
                            reply_markup=button,
                        )
                    playlist = db.get(chat_id)
                    if playlist and isinstance(playlist, list) and len(playlist) > 0:
                        playlist[0]["mystic"] = run
                        playlist[0]["markup"] = "stream"
                        playlist[0]["base_caption"] = caption


    async def start(self) -> None:
        LOGGER(__name__).info("Starting PyTgCalls Clients...")
        if config.STRING1:
            await self.one.start()
        if config.STRING2:
            await self.two.start()
        if config.STRING3:
            await self.three.start()
        if config.STRING4:
            await self.four.start()
        if config.STRING5:
            await self.five.start()

    @capture_internal_err
    async def ping(self) -> str:
        pings = []
        if config.STRING1:
            pings.append(self.one.ping)
        if config.STRING2:
            pings.append(self.two.ping)
        if config.STRING3:
            pings.append(self.three.ping)
        if config.STRING4:
            pings.append(self.four.ping)
        if config.STRING5:
            pings.append(self.five.ping)
        return str(round(sum(pings) / len(pings), 3)) if pings else "0.0"

    @capture_internal_err
    async def decorators(self) -> None:
        assistants = list(filter(None, [self.one, self.two, self.three, self.four, self.five]))

        CRITICAL = (
            ChatUpdate.Status.KICKED
            | ChatUpdate.Status.LEFT_GROUP
            | ChatUpdate.Status.CLOSED_VOICE_CHAT
            | ChatUpdate.Status.DISCARDED_CALL
            | ChatUpdate.Status.BUSY_CALL
        )

        async def unified_update_handler(client, update: Update) -> None:
            try:
                if isinstance(update, ChatUpdate):
                    status = update.status
                    if (status & ChatUpdate.Status.LEFT_CALL) or (status & CRITICAL):
                        await self.stop_stream(update.chat_id)
                        return

                elif isinstance(update, StreamEnded):
                    # Handle both AUDIO and VIDEO stream endings.
                    # The original AUDIO-only guard meant video streams never
                    # triggered queue advance or autoplay.
                    assistant = await group_assistant(self, update.chat_id)
                    await self.play(assistant, update.chat_id)

            except Exception:
                import sys, traceback
                exc_type, exc_obj, exc_tb = sys.exc_info()
                err_msg = str(exc_obj)[:200]
                caption = (
                    f"🚨 <b>Stream Error</b>\n"
                    f"📍 <b>Type:</b> <code>{exc_type.__name__}</code>\n"
                    f"💬 <b>Error:</b> <code>{err_msg}</code>\n"
                    f"📌 <b>Chat:</b> <code>{getattr(update, 'chat_id', '?')}</code>"
                )
                try:
                    full_trace = "".join(traceback.format_exception(exc_type, exc_obj, exc_tb))
                    paste_url = await VISHALBIN(full_trace)
                    if paste_url:
                        caption += f"\n🔗 <b>Log:</b> {paste_url}"
                except Exception:
                    pass
                try:
                    await app.send_message(config.LOGGER_ID, caption)
                except Exception:
                    pass

        for assistant in assistants:
            assistant.on_update()(unified_update_handler)


VISHAL = Call()

# ═══════════════════════════════════════════════════════════
#        😎  KRISH X STAR MUSIC BOT  😎
#   t.me/iwanthotpinkpussy
# ═══════════════════════════════════════════════════════════
